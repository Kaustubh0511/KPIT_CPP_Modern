#ifndef STRUCTOX_HPP
#define STRUCTOX_HPP

#include <iostream>
using namespace std;

struct Ox
{
    void OxFun()
    {
        cout << "OX::oxFun\n";
    }
};

#endif // STRUCTOX_HPP
