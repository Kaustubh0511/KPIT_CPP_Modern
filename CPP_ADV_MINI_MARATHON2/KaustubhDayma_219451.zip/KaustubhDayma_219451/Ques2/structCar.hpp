#ifndef STRUCTCAR_HPP
#define STRUCTCAR_HPP

#include<iostream>
using namespace std;

struct Car
{
    void carFun()
    {
        cout<<"CAR::carFun\n";
    }
};

#endif // STRUCTCAR_HPP
