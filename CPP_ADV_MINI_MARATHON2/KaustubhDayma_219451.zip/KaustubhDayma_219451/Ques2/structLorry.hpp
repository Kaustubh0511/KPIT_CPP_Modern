#ifndef STRUCTLORRY_HPP
#define STRUCTLORRY_HPP

#include<iostream>
using namespace std;

struct Lorry
{
    void lorryFun()
    {
        cout<<"Lorry::lorryFun\n";
    }
};




#endif // STRUCTLORRY_HPP
