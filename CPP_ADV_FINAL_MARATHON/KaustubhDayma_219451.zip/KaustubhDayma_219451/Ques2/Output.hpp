#ifndef OUTPUT_HPP
#define OUTPUT_HPP

#include "ResearchOrganisationList.hpp"

class Output
{
    
};
#endif // OUTPUT_HPP
