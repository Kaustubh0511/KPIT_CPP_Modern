#include "Test.hpp"
#include "ResearchOrganisationList.hpp"

int main()
{
    ResearchOrgainiasationList researchOrgList;
    start(researchOrgList);
    cout << researchOrgList << "\n";
    return 0;
}