#include "SQL.hpp"

void SQL::OpenDB()
{
    cout << "Open SQL DB\n";
}

void SQL::CloseDB()
{
    cout << "Close SQL DB\n";
}