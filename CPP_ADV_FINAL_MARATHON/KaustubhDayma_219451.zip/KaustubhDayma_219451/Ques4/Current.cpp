#include "Current.hpp"

void Current::DoDebit(int Accid, int amount)
{
    cout << "Debit Current\n";
}