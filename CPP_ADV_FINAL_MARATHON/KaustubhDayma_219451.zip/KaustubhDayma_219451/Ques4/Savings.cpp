#include "Savings.hpp"

void Savings::DoDebit(int Accid, int amount)
{
    cout << "Debit Savings\n";
}

