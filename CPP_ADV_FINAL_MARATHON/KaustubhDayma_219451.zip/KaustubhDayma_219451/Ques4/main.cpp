#include "Start.hpp"

int main()
{
    Start();
    return 0;
}