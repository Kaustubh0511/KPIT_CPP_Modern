#include "feature.hpp"

int main()
{
    DOG d;
    CAT c;
    OX o;

    Function_Variant(d);
    Function_Variant(c);
    Function_Variant(o);
    return 0;
}
