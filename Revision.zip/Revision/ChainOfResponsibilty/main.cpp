#include "functions.hpp"

int main()
{
    functions();
    return 0;
}