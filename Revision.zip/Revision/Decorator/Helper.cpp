#include "Helper.hpp"

void Helper::Send(string msg)
{
    msg_send->Send(msg);
}
