#include "functions.hpp"

int main()
{
    fucntions();
    return 0;
}