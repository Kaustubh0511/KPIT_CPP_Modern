#include "functionsInter.hpp"

int main()
{
    start();
    return 0;
}