#include "function.hpp"

int main()
{
    function();
    cout << "-----------------------------\n";
    Test();
    return 0;
}