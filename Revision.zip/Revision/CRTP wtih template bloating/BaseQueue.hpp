#ifndef BASEQUEUE_HPP
#define BASEQUEUE_HPP
#include <iostream>
using namespace std;

template <typename T>
class Queue
{
    T arr[10];
    
};

#endif // BASEQUEUE_HPP
