#include "Functionality.h"

int main()
{
    functionality();
    return 0;
}