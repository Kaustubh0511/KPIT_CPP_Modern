#ifndef FUNCTIONALITY_H
#define FUNCTIONALITY_H

#include"Factory.h"

void functionality();


#endif // FUNCTIONALITY_H
