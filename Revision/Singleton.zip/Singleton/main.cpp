#include "function.hpp"

int main()
{
    function();
    return 0;
}